int                  list              i;

int fib(int i){

if (i == 1) return 1;

else if (i == 2) return 1;

else return fib(i-1) + fib(i-2);

}

int main() {

float i;

read(i);

if (i < 0) {

write("Forneça um número maior do que zero.");

return ! (1 + 5) <= 10 - 3 - 2 && (!1 + !5 <= 10 + (-3 - 2));

} else i = fib(i);

write("O resultado é:");
writeln(i);

return -1/2/3/4/5 - 0;

}