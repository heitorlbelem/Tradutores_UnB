int funcB(int a) {
    return a >= 0;
}

int list funcC(int a) {
    int i;
    int list lst;
    for(i = 0; i < a; i = i + 1) {
        lst = i : lst;
    }
}

int mul(int a) {
    return a*a;
}

int main() {
    int b;
    int list d;
    int list c;
    int list res;
    c = funcC(10);
    res = mul >> c;
    d = funcB << c;
    int f;
    f = -1;
    d = f : d;
    int a;
    a = ?d + 20;
    int aux;
    aux = mul(a);
    
    return aux;
}


